package com.capgemini.bookstore.dao;

public interface QueryMapper {
	public static final String RETRIVE_ALL_QUERY="select * from Category_management";
	public static final String INSERT_QUERY="insert into category_management values(index_seq.NEXTVAL,?,id_seq.NEXTVAL)";
	public static final String DELETE_QUERY="delete from category_management where id_seq=?";
	public static final String EDIT_QUERY="update category_management set category_name=? where id_seq=?";
	public static final String LOGIN_QUERY="select * from admin where email=? and password=?";
    public static final String VERIFY_QUERY="SELECT*FROM Category_Management WHERE id_seq=?";
}
