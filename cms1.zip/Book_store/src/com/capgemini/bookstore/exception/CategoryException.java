package com.capgemini.bookstore.exception;

public class CategoryException extends Exception{
	private static final long serialVersionUID = 726264577455921591L;

	public CategoryException(String message) 
	{
		
		super(message);
	}

}
