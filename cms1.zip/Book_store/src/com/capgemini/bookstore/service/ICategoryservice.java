package com.capgemini.bookstore.service;

import java.sql.SQLException;

import com.capgemini.bookstore.bean.Categorybean;
import com.capgemini.bookstore.exception.CategoryException;

public interface ICategoryservice {
	 public void addCategoryDetails(Categorybean PBobj) throws CategoryException;
	 public void retriveAll();
	 public void deleteCategoryDetails(String id1);
	 public void editCategoryDetails(String id2, String cname) ;
	 public int isValidId(String id1) throws SQLException, CategoryException;

}
